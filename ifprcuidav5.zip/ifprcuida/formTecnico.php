<?php include("header.php"); ?>

<div class="d-flex justify-content-center mt-4">
    <h2>Cadastrar Técnico:</h2>
</div>

<?php
// Exibe os alertas de erro/validação caso venham na URL
if (isset($_GET['erroCadastro'])) {
    $erro = $_GET['erroCadastro'];

    if ($erro === 'senhasDiferentes') {
        echo "<div class='alert alert-danger text-center container style='max-width: 500px;'>As senhas informadas não coincidem!</div>";
    } elseif ($erro === 'camposVazios') {
        echo "<div class='alert alert-warning text-center container style='max-width: 500px;'>Preencha todos os campos obrigatórios!</div>";
    } elseif ($erro === 'erroSql') {
        echo "<div class='alert alert-danger text-center container style='max-width: 500px;'>Erro ao tentar salvar no banco de dados.</div>";
    }
}
?>

<div class="d-flex justify-content-center">
    <form action="actionTecnico.php" method="POST" class="was-validated">
        
        <div class="form-floating mt-3 mb-3">
            <input type="text" name="nomeTecnico" id="nomeTecnico" placeholder="Nome Completo" class="form-control" required>
            <label for="nomeTecnico">Nome do Técnico</label>
        </div>

        <div class="form-floating mt-3 mb-3">
            <input type="text" name="idSiape" id="idSiape" placeholder="SIAPE" class="form-control" required>
            <label for="idSiape">SIAPE (Matrícula)</label>
        </div>

        <div class="form-floating mt-3 mb-3">
            <input type="email" name="emailTecnico" id="emailTecnico" placeholder="Email" class="form-control" required>
            <label for="emailTecnico">E-mail</label>
        </div>

        <div class="form-floating mt-3 mb-3">
            <input type="password" name="senhaTecnico" id="senhaTecnico" placeholder="Senha" class="form-control" minlength="3" maxlength="32" required>
            <label for="senhaTecnico">Senha</label>
        </div>

        <div class="form-floating mt-3 mb-3">
            <input type="password" name="confirmarSenhaTecnico" id="confirmarSenhaTecnico" placeholder="Confirmar Senha" class="form-control" minlength="3" maxlength="32" required>
            <label for="confirmarSenhaTecnico">Confirmar Senha</label>
        </div>

        <button type="submit" class="btn btn-outline-dark">Cadastrar Técnico</button>

    </form>
</div>

<?php include("footer.php"); ?>