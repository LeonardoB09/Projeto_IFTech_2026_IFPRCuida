<?php
session_start();
include "conexaoBD.php"; 

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['emailUsuario']) && !empty($_POST['senhaUsuario'])) {
    
    $emailUsuario = trim($_POST['emailUsuario']);
    $senhaUsuario = trim($_POST['senhaUsuario']);
    $senhaMd5     = md5($senhaUsuario);

    // Consulta na tabela usuarios
    $stmt = mysqli_prepare($conn, "SELECT id_usuario, matricula_usuario, nome_usuario, email_usuario, senha_usuario, nivel_usuario FROM usuarios WHERE email_usuario = ? LIMIT 1");

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $emailUsuario);
        mysqli_stmt_execute($stmt);
        $resultado = mysqli_stmt_get_result($stmt);

        if ($resultado && $registro = mysqli_fetch_assoc($resultado)) {
            
            // Verifica a senha em MD5
            if ($senhaMd5 === $registro['senha_usuario']) {
                
                // Grava as informações no servidor
                $_SESSION['idUsuario']        = $registro['id_usuario'];
                $_SESSION['matriculaUsuario'] = $registro['matricula_usuario'];
                $_SESSION['nomeUsuario']      = $registro['nome_usuario'];
                $_SESSION['emailUsuario']     = $registro['email_usuario'];
                $_SESSION['nivelUsuario']     = $registro['nivel_usuario']; // Ex: 'Estudante', 'Tecnico'
                $_SESSION['logado']           = true;

                mysqli_stmt_close($stmt);

                header("Location: index.php");
                exit();
            }
        }
        mysqli_stmt_close($stmt);
    }
}

// Em caso de dados inválidos
header("Location: formLogin.php?erroLogin=dadosInvalidos");
exit();