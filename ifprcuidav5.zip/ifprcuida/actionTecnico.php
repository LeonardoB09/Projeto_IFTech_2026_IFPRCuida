<?php
require_once "conexaoBD.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nomeTecnico           = trim($_POST['nomeTecnico'] ?? '');
    $idSiape               = trim($_POST['idSiape'] ?? '');
    $emailTecnico          = trim($_POST['emailTecnico'] ?? '');
    $senhaTecnico          = trim($_POST['senhaTecnico'] ?? '');
    $confirmarSenhaTecnico = trim($_POST['confirmarSenhaTecnico'] ?? '');

    // 1. Valida se algum campo ficou vazio
    if (empty($nomeTecnico) || empty($idSiape) || empty($emailTecnico) || empty($senhaTecnico) || empty($confirmarSenhaTecnico)) {
        header("Location: formTecnico.php?erroCadastro=camposVazios");
        exit();
    }

    // 2. Valida se as senhas conferem
    if ($senhaTecnico !== $confirmarSenhaTecnico) {
        header("Location: formTecnico.php?erroCadastro=senhasDiferentes");
        exit();
    }

    // 3. Prepara os dados para inserção na tabela 'usuarios'
    $senhaMd5     = md5($senhaTecnico);
    $nivelUsuario = 'Tecnico'; // Define o nível como Técnico automaticamente

    // 4. Grava no banco de dados
    $sql  = "INSERT INTO usuarios (matricula_usuario, nome_usuario, email_usuario, senha_usuario, nivel_usuario) VALUES (?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "sssss", $idSiape, $nomeTecnico, $emailTecnico, $senhaMd5, $nivelUsuario);

        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            
            // Cadastro com sucesso! Redireciona para o formulário de login
            header("Location: formLogin.php?sucessoCadastro=1");
            exit();
        } else {
            mysqli_stmt_close($stmt);
            header("Location: formTecnico.php?erroCadastro=erroSql");
            exit();
        }
    } else {
        header("Location: formTecnico.php?erroCadastro=erroSql");
        exit();
    }

} else {
    header("Location: formTecnico.php");
    exit();
}