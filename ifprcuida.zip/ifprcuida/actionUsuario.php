<?php
// 1. Requer a conexão no início do arquivo.
// Se o arquivo 'conexaoBD.php' não existir, o script para aqui e avisa o erro.
require_once "conexaoBD.php";

// Função para filtrar entrada de dados
function filtrar_entrada($dado){
    $dado = trim($dado); // Remove espaços desnecessários
    $dado = stripslashes($dado); // Remove barras invertidas
    $dado = htmlspecialchars($dado); // Converte caracteres especiais em entidades HTML
    return $dado;
}

// Verifica se o método de envio do formUsuario é POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Cria variáveis para armazenar as informações passadas pelo $_POST[]
    $nomeUsuario = $matriculaUsuario = $emailUsuario = $senhaUsuario = $confirmarSenhaUsuario = "";

    // Variável booleana para controle de erros de preenchimento
    $erroPreenchimento = false;

    // Validação do campo nomeUsuario
    if (empty($_POST["nomeUsuario"])) {
        echo "<div class='alert alert-warning text-center'>O campo <strong>NOME</strong> é obrigatório!</div>";
        $erroPreenchimento = true;
    } else {
        $nomeUsuario = filtrar_entrada($_POST["nomeUsuario"]);

        if (!preg_match('/^[\p{L} ]+$/u', $nomeUsuario)) {
            echo "<div class='alert alert-warning text-center'>O campo <strong>NOME</strong> deve conter apenas letras!</div>";
            $erroPreenchimento = true;
        }
    }

    // Validação do campo matriculaUsuario
    if (empty($_POST["matriculaUsuario"])) {
        echo "<div class='alert alert-warning text-center'>O campo <strong>MATRÍCULA</strong> é obrigatório!</div>";
        $erroPreenchimento = true;
    } else {
        $matriculaUsuario = filtrar_entrada($_POST["matriculaUsuario"]);
    }

    // Validação do campo emailUsuario
    if (empty($_POST["emailUsuario"])) {
        echo "<div class='alert alert-warning text-center'>O campo <strong>EMAIL</strong> é obrigatório!</div>";
        $erroPreenchimento = true;
    } else {
        $emailUsuario = filtrar_entrada($_POST["emailUsuario"]);
    }

    // Validação do campo senhaUsuario
    if (empty($_POST["senhaUsuario"])) {
        echo "<div class='alert alert-warning text-center'>O campo <strong>SENHA</strong> é obrigatório!</div>";
        $erroPreenchimento = true;
    } else {
        $senhaUsuario = md5(filtrar_entrada($_POST["senhaUsuario"]));
    }

    // Validação do campo confirmarSenhaUsuario
    if (empty($_POST["confirmarSenhaUsuario"])) {
        echo "<div class='alert alert-warning text-center'>O campo <strong>CONFIRMAR SENHA</strong> é obrigatório!</div>";
        $erroPreenchimento = true;
    } else {
        $confirmarSenhaUsuario = md5(filtrar_entrada($_POST["confirmarSenhaUsuario"]));

        if ($senhaUsuario != $confirmarSenhaUsuario) {
            echo "<div class='alert alert-warning text-center'>As <strong>SENHAS</strong> informadas são diferentes!</div>";
            $erroPreenchimento = true;
        }
    }

    // Se não houver erros de preenchimento, realiza a inserção dos dados no BD
    if (!$erroPreenchimento) {
        
        $inserirUsuario = "INSERT INTO Usuarios (nome_usuario, matricula_usuario, email_usuario, senha_usuario, nivel_usuario)
                           VALUES ('$nomeUsuario', '$matriculaUsuario', '$emailUsuario', '$senhaUsuario', 'usuario')";

        // Executa a QUERY no BD usando a variável $conn declarada em conexaoBD.php
        if (mysqli_query($conn, $inserirUsuario)) {

            echo "<div class='alert alert-success text-center'>Os dados do <strong>USUÁRIO</strong> foram cadastrados com sucesso!</div>";
            echo "
                <div class='container mt-3 mb-3'>
                    <table class='table table-bordered'>
                        <tr>
                            <th>NOME</th>
                            <td>$nomeUsuario</td>
                        </tr>
                        <tr>
                            <th>MATRÍCULA</th>
                            <td>$matriculaUsuario</td>
                        </tr>
                        <tr>
                            <th>EMAIL</th>
                            <td>$emailUsuario</td>
                        </tr>
                    </table>
                </div>
            ";
        } else {
            echo "<div class='alert alert-danger text-center'>Erro ao tentar cadastrar <strong>USUÁRIO</strong> no banco de dados: " . mysqli_error($conn) . "</div>";
        }
    }
} else {
    header("location:formUsuario.php");
    exit();
}
?>