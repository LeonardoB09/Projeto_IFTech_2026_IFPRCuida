<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title>IFPR CUIDA</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <link href="css/styles.css" rel="stylesheet" />
        
        <style>
            body {
                display: flex;
                flex-direction: column;
                min-height: 100vh;
            }

            .custom-header {
                background-color: #90eb64;
                padding: 1rem 0;
                width: 100%;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }

            .header-container {
                display: flex;
                align-items: center;
                max-width: 1320px;
                margin: 0 auto;
                padding: 0 1.5rem;
            }

            .logo-link {
                display: flex;
                align-items: center;
                text-decoration: none;
                color: inherit;
            }

            .logo-group {
                display: flex;
                align-items: center;
                gap: 1rem;
            }

            .logo-img {
                height: 110px; /* Altura ideal para o cabeçalho */
                width: auto;  /* Mantém a proporção da imagem */
                object-fit: contain;
            }

            .logo-title {
                margin: 0;
                font-size: 1.5rem;
                font-weight: 700;
                color: #000;
            }

            .logo-subtitle {
                margin: 0;
                font-size: 0.75rem;
                color: #000;
            }

            .custom-nav {
                flex-grow: 1;
                display: flex;
                justify-content: center;
            }

            .nav-list {
                list-style: none;
                padding: 0;
                margin: 0;
                display: flex;
                gap: 2rem;
            }

            .nav-list li a {
                text-decoration: none;
                color: #000;
                text-transform: uppercase;
                font-weight: 600;
                font-size: 0.95rem;
            }

            main {
                flex: 1; /* Garante que o conteúdo empurre o rodapé para o final da página */
            }
        </style>
    </head>
    <body>
        <header class="custom-header">
            <div class="header-container">
                <a href="index.php" class="logo-link">
                    <div class="logo-group">
                        <img src="img/Gemini_Generated_Image_5zjl5x5zjl5x5zjl (2).png" alt="Logo IFPR CUIDA" class="logo-img">
                        <div class="logo-text">
                            <h2 class="logo-title">IFPR CUIDA</h2>
                            <p class="logo-subtitle">Sistema de Apoio à Saúde Mental Estudantil</p>
                        </div>
                    </div>
                </a>
                <nav class="custom-nav">
                    <ul class="nav-list">
                        <li><a href="index.php">INÍCIO</a></li>
                        <li><a href="index.php#about">COMO FUNCIONA</a></li>
                        <li><a href="index.php#contact">CONTATOS</a></li>
                        <li><a href="formUsuario.php">CADASTRAR-SE</a></li>
                        <li><a href="formLogin.php">LOGIN</a></li>
                    </ul>
                </nav>
            </div>
        </header>

        <!-- Abertura do conteúdo principal -->
        <main class="py-5">