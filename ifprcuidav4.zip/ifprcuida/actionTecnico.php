<?php
// 1. Requer a conexão no início do arquivo.
require_once "conexaoBD.php";

// Função para filtrar entrada de dados
function filtrar_entrada($dado){
    $dado = trim($dado); // Remove espaços desnecessários
    $dado = stripslashes($dado); // Remove barras invertidas
    $dado = htmlspecialchars($dado); // Converte caracteres especiais em entidades HTML
    return $dado;
}

// Verifica se o método de envio é POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    
    if (!empty($_POST["nomeTecnico"])) {

        // Cria variáveis para armazenar as informações passadas pelo $_POST[]
        $nomeTecnico = $idSiape = $cargoTecnico = $emailTecnico = $senhaTecnico = $confirmarSenhaTecnico = "";

        // Variável booleana para controle de erros de preenchimento
        $erroPreenchimento = false;

        // Guardaremos as mensagens de erro para exibir formatadas
        $mensagensErro = [];

        // Validação do campo nomeTecnico
        if (empty($_POST["nomeTecnico"])) {
            $mensagensErro[] = "O campo <strong>NOME</strong> é obrigatório!";
            $erroPreenchimento = true;
        } else {
            $nomeTecnico = filtrar_entrada($_POST["nomeTecnico"]);

            if (!preg_match('/^[\p{L} ]+$/u', $nomeTecnico)) {
                $mensagensErro[] = "O campo <strong>NOME</strong> deve conter apenas letras!";
                $erroPreenchimento = true;
            }
        }

        // Validação do campo idSiape
        if (empty($_POST["idSiape"])) {
            $mensagensErro[] = "O campo <strong>SIAPE</strong> é obrigatório!";
            $erroPreenchimento = true;
        } else {
            $idSiape = filtrar_entrada($_POST["idSiape"]);
        }

        // Validação do campo cargoTecnico
        if (empty($_POST["cargoTecnico"])) {
            $mensagensErro[] = "O campo <strong>CARGO</strong> é obrigatório!";
            $erroPreenchimento = true;
        } else {
            $cargoTecnico = filtrar_entrada($_POST["cargoTecnico"]);
        }

        // Validação do campo emailTecnico
        if (empty($_POST["emailTecnico"])) {
            $mensagensErro[] = "O campo <strong>EMAIL</strong> é obrigatório!";
            $erroPreenchimento = true;
        } else {
            $emailTecnico = (filtrar_entrada($_POST["emailTecnico"]));
            }
        }

        // Validação do campo senhaTecnico
        if (empty($_POST["senhaTecnico"])) {
            $mensagensErro[] = "O campo <strong>SENHA</strong> é obrigatório!";
            $erroPreenchimento = true;
        } else {
            $senhaTecnico = md5(filtrar_entrada($_POST["senhaTecnico"]));
        }

        // Validação do campo confirmarSenhaTecnico
        if (empty($_POST["confirmarSenhaTecnico"])) {
            $mensagensErro[] = "O campo <strong>CONFIRMAR SENHA</strong> é obrigatório!";
            $erroPreenchimento = true;
        } else {
            $confirmarSenhaTecnico = md5(filtrar_entrada($_POST["confirmarSenhaTecnico"]));

            if ($senhaTecnico !== $confirmarSenhaTecnico) {
                $mensagensErro[] = "As <strong>SENHAS</strong> informadas são diferentes!";
                $erroPreenchimento = true;
            }
        }
        // SE HOUVER ERROS DE PREENCHIMENTO:
        if ($erroPreenchimento) {
            include "header.php";
            echo "<div class='container my-4' style='max-width: 600px;'>";
            foreach ($mensagensErro as $erro) {
                echo "<div class='alert alert-warning text-center'>$erro</div>";
            }
            echo "<div class='text-center mt-3'><a href='javascript:history.back()' class='btn btn-dark'>Voltar e Corrigir</a></div>";
            echo "</div>";
            include "footer.php";
        } 
        // SE NÃO HOUVER ERROS: Tenta gravar no banco e exibe a Tela de Sucesso
        else {
            
            // Inserção na tabela 'tecnico'
            $inserirTecnico = "INSERT INTO tecnico (id_siape, nome_tecnico, cargo_tecnico, email_tecnico, senha_tecnico, nivel_usuario)
                       VALUES ('$idSiape', '$nomeTecnico', '$cargoTecnico', '$emailTecnico', '$senhaTecnico', 'Tecnico')";

            if (mysqli_query($conn, $inserirTecnico)) {
                
                include "header.php";
                ?>

                <!-- Redireciona automaticamente para o index.php após 4 segundos -->
                <meta http-equiv="refresh" content="4;url=index.php">

                <div class="container d-flex justify-content-center align-items-center my-5">
                    <div class="card text-center p-4 shadow-sm border-0" style="max-width: 480px; width: 100%; border-radius: 15px; background-color: #f8f9fa;">
                        <div class="card-body">
                            
                            <!-- Ícone de Sucesso -->
                            <div class="mb-3">
                                <i class="bi bi-check-circle-fill text-success" style="font-size: 3.5rem;"></i>
                            </div>

                            <!-- Título e Mensagem -->
                            <h3 class="card-title fw-bold mb-2" style="color: #2b4c2a;">Cadastro Realizado!</h3>
                            <p class="card-text text-muted mb-3">
                                Os dados do técnico foram cadastrados com sucesso.
                            </p>

                            <!-- Tabela de Confirmação dos Dados Cadastrados -->
                            <table class="table table-bordered table-sm text-start mb-4">
                                <tr>
                                    <th class="bg-light" style="width: 35%;">NOME:</th>
                                    <td><?php echo $nomeTecnico; ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-light">SIAPE:</th>
                                    <td><?php echo $idSiape; ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-light">CARGO:</th>
                                    <td><?php echo $cargoTecnico; ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-light">EMAIL:</th>
                                    <td><?php echo $emailTecnico; ?></td>
                                </tr>
                            </table>

                            <!-- Botão de Ação Imediata -->
                            <div class="d-grid gap-2">
                                <a href="index.php" class="btn btn-success btn-lg fs-6 fw-bold" style="background-color: #00a84f; border: none;">
                                    <i class="bi bi-house-door me-2"></i>Ir para o Início
                                </a>
                            </div>

                            <p class="text-muted small mt-3 mb-0">
                                Redirecionando para a página inicial em 4 segundos...
                            </p>

                        </div>
                    </div>
                </div>

                <?php
                include "footer.php";

            } else {
                include "header.php";
                echo "<div class='container my-4 text-center' style='max-width: 600px;'>";
                echo "<div class='alert alert-danger'>Erro ao tentar cadastrar <strong>TÉCNICO</strong> no banco de dados: " . mysqli_error($conn) . "</div>";
                echo "<a href='javascript:history.back()' class='btn btn-dark mt-2'>Voltar</a>";
                echo "</div>";
                include "footer.php";
            }
        }
   
 } else {
    header("location:formTecnico.php");
    exit();
}
?>