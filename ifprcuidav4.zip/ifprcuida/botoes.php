<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IFPR CUIDA - Seleção de Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-color: #ffffff;
        }

        header, footer {
            background-color: #6a9c68;
            padding: 20px;
            text-align: center;
        }

        header img {
            max-width: 120px;
            height: auto;
            display: block;
            margin: 0 auto 10px;
        }

        .header-title {
            color: #ffffff;
            font-size: 1.1rem;
            font-weight: bold;
        }

        footer {
            height: 60px;
            margin-top: auto;
        }

        /* Conteúdo centralizado */
        main {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        h1 {
            color: #1b4d2e;
            font-size: 1.8rem;
            margin-bottom: 40px;
            text-align: center;
            font-weight: bold;
            letter-spacing: 0.5px;
        }

        .buttons-container {
            display: flex;
            flex-direction: column;
            gap: 25px;
            width: 100%;
            max-width: 320px;
        }

        .btn {
            display: block;
            width: 100%;
            padding: 14px 0;
            background-color: #0b9e4a;
            color: #ffffff;
            text-align: center;
            text-decoration: none;
            font-weight: bold;
            font-size: 1rem;
            border-radius: 25px;
            transition: background-color 0.2s ease, transform 0.1s ease;
        }

        .btn:hover {
            background-color: #09833d;
        }

        .btn:active {
            transform: scale(0.98);
        }
    </style>
</head>
<body>

    <header>
        <img src="img/Gemini_Generated_Image_5zjl5x5zjl5x5zjl%20(2).png" alt="IFPR CUIDA" width="700" >
    </header>

    <main>
        <h1>COMO VOCÊ DESEJA LOGAR?</h1>

        <div class="buttons-container">
            <a href="formLoginTecnico.php" class="btn">TÉCNICO</a>
            <a href="formLogin.php" class="btn">ALUNO</a>
        </div>
    </main>

    <footer></footer>

</body>
</html>