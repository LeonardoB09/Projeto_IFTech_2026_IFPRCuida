<?php include "header.php"; ?>

    <?php
        $erroLogin = '';
        $emailTecnico = '';

        // Verifica se há alguma passagem de parâmetro via método GET chamada 'erroLogin'
        if(isset($_GET['erroLogin'])){
            $erroLogin = filter_input(INPUT_GET, 'erroLogin', FILTER_SANITIZE_STRING);
            $emailTecnico = filter_input(INPUT_GET, 'emailTecnico', FILTER_SANITIZE_EMAIL);

            if($erroLogin === 'dadosInvalidos'){
                echo "<div class='alert alert-warning text-center'>EMAIL ou SENHA inválidos!</div>";
            }
        }
    ?>

    <div class="d-flex justify-content-center">
        <h2>Acessar como Técnico:</h2>
    </div>

    <div class="d-flex justify-content-center">
        <form action="actionTecnico.php" method="POST" class="was-validated">
            
            <div class="form-floating mt-3 mb-3">
                <input type="email" name="emailTecnico" id="emailTecnico" placeholder="Email" class="form-control" value="<?php echo htmlspecialchars($emailTecnico); ?>" required>
                <label for="emailTecnico">Email</label>
                <div class="valid-feedback"></div>
            </div>

            <div class="form-floating mt-3 mb-3">
                <input type="password" name="senhaTecnico" id="senhaTecnico" placeholder="Senha" class="form-control" minlength="3" maxlength="8" required>
                <label for="senhaTecnico">Senha</label>
                <div class="valid-feedback"></div>
            </div>

            <button type="submit" class="btn btn-outline-dark">Login</button>

        </form>
    </div>

    <div class="d-flex justify-content-center mt-3">
        <p>Ainda não possui cadastro técnico? <a href="formTecnico.php" title="Cadastrar-se">Clique aqui!</a>&nbsp;<i class="bi bi-emoji-smile"></i></p>
    </div>

<?php include "footer.php"; ?>