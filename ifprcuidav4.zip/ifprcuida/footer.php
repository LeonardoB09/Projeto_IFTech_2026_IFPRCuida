</main> <!-- Fechamento da tag main -->

        <footer class="py-4 text-white text-center" style="position: static; background-color: #5B8C5A; width:100%;">
            <div class="container">
                <p class="m-0">Copyright &copy; IFPR CUIDA 2026</p>
            </div>
        </footer>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>