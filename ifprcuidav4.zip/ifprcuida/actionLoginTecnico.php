<?php
    include "conexaoBD.php"; // Inclui o arquivo de conexão com o BD para consultar técnicos
    session_start(); // Função para iniciar uma sessão

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['emailTecnico'], $_POST['senhaTecnico'])) {
        // Captura e limpa os dados enviados pelo formulário de login do técnico
        $emailTecnico = mysqli_real_escape_string($conn, trim($_POST['emailTecnico']));
        $senhaTecnico = trim($_POST['senhaTecnico']);
        $senhaHash = md5($senhaTecnico);

        // Consulta na tabela 'tecnico'
        $buscarLogin = "SELECT *
                        FROM tecnico
                        WHERE email_tecnico = '$emailTecnico'
                        AND senha_tecnico = '$senhaTecnico'
                        LIMIT 1";

        // Executa a QUERY
        $efetuarLogin = mysqli_query($conn, $buscarLogin);

        // Verifica se a consulta encontrou algum registro associado
        if ($efetuarLogin && $registro = mysqli_fetch_assoc($efetuarLogin)) {
            // Criar variáveis de sessão específicas para o técnico
            $_SESSION['idTecnico']    = $registro['id_tecnico'] ?? $registro['idTecnico'];
            $_SESSION['idSiape']      = $registro['id_siape'];
            $_SESSION['nomeTecnico']  = $registro['nome_tecnico'];
            $_SESSION['emailTecnico'] = $registro['email_tecnico'];
            $_SESSION['cargoTecnico'] = $registro['cargo_tecnico'];
            $_SESSION['tipoUsuario']  = 'tecnico'; // Util para diferenciar acessos/permissões no sistema
            $_SESSION['logado']       = true;

            // Redireciona para a página inicial ou painel do técnico
            header("Location: index.php");
            exit();
        }
    }

    // Redireciona o técnico de volta para o formulário de login com erro
    header("Location: formLoginTecnico.php?erroLogin=dadosInvalidos");
    exit();
?>