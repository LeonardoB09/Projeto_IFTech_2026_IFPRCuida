<?php include("header.php"); ?>

<div class="d-flex justify-content-center">
    <h2>Cadastrar Técnico:</h2>
</div>

<?php
// Validação em servidor: verifica se as senhas batem quando o formulário é enviado para este arquivo
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $senha = isset($_POST['senhaTecnico']) ? trim($_POST['senhaTecnico']) : '';
    $confirmar = isset($_POST['confirmarSenhaTecnico']) ? trim($_POST['confirmarSenhaTecnico']) : '';
    if ($senha === '' || $confirmar === '') {
        $error = 'Preencha ambos os campos de senha.';
    } elseif ($senha !== $confirmar) {
        $error = 'As senhas não coincidem.';
    }
}
?>

<?php if ($error): ?>
    <div class="d-flex justify-content-center mt-3">
        <div class="alert alert-danger" role="alert"><?php echo htmlspecialchars($error); ?></div>
    </div>
<?php endif; ?>

<div class="d-flex justify-content-center">
    <form action="actionTecnico.php" method="POST" class="was-validated">
        
        <div class="form-floating mt-3 mb-3">
            <input type="text" name="nomeTecnico" id="nomeTecnico" placeholder="Nome Completo" class="form-control" required>
            <label for="nomeTecnico">Nome do Técnico</label>
            <div class="valid-feedback"></div>
            <div class="invalid-feedback"></div>
        </div>

        <div class="form-floating mt-3 mb-3">
            <input type="text" name="idSiape" id="idSiape" placeholder="SIAPE" class="form-control" required>
            <label for="idSiape">SIAPE</label>
            <div class="valid-feedback"></div>
            <div class="invalid-feedback"></div>
        </div>

        <div class="form-floating mt-3 mb-3">
            <input type="text" name="cargoTecnico" id="cargoTecnico" placeholder="Cargo" class="form-control" required>
            <label for="cargoTecnico">Cargo</label>
            <div class="valid-feedback"></div>
            <div class="invalid-feedback"></div>
        </div>

        <div class="form-floating mt-3 mb-3">
            <input type="email" name="emailTecnico" id="emailTecnico" placeholder="Email" class="form-control" required>
            <label for="emailTecnico">Email</label>
            <div class="valid-feedback"></div>
            <div class="invalid-feedback"></div>
        </div>

        <div class="form-floating mt-3 mb-3">
            <input type="password" name="senhaTecnico" id="senhaTecnico" placeholder="Senha" class="form-control" minlength="3" maxlength="8" required>
            <label for="senhaTecnico">Senha</label>
            <div class="valid-feedback"></div>
            <div class="invalid-feedback"></div>
        </div>

        <div class="form-floating mt-3 mb-3">
            <input type="password" name="confirmarSenhaTecnico" id="confirmarSenhaTecnico" placeholder="Confirmar Senha" class="form-control" minlength="3" maxlength="8" required>
            <label for="confirmarSenhaTecnico">Confirmar Senha</label>
            <div class="valid-feedback"></div>
            <div class="invalid-feedback"></div>
        </div>

        <button type="submit" class="btn btn-outline-dark">Cadastrar Técnico</button>

    </form>
</div>

<?php include("footer.php"); ?>