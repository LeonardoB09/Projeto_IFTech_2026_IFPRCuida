<?php

    $hostBD   = "localhost"; //Define o local do servidor de BD
    $userBD   = "root"; //Define o usuário do BD (Padrão: root)
    $senhaBD  = "root"; //Define a senha do BD (Padrão: "" [Em branco])
    $database = "ifprcuida"; //Define com qual base será realizada a conexão

    //Função do PHP para estabelecer a conexão com o BD
    $conn = mysqli_connect($hostBD, $userBD, $senhaBD, $database);

    //Verifica se há conexão com BD
    if(!$conn){
        echo "<p>Erro ao tentar conectar a aplicação à base de dados <strong>$database</strong>!<br>";
        echo "Detalhes: " . mysqli_connect_error() . "</p>";
        exit();
    }

    mysqli_set_charset($conn, 'utf8');

?>