<?php

include "header.php";

require_once "conexaoBD.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nomeTecnico           = trim($_POST['nomeTecnico'] ?? '');
    $idSiape               = trim($_POST['idSiape'] ?? '');
    $emailTecnico          = trim($_POST['emailTecnico'] ?? '');
    $senhaTecnico          = trim($_POST['senhaTecnico'] ?? '');
    $confirmarSenhaTecnico = trim($_POST['confirmarSenhaTecnico'] ?? '');

    // 1. Valida se algum campo ficou vazio
    if (empty($nomeTecnico) || empty($idSiape) || empty($emailTecnico) || empty($senhaTecnico) || empty($confirmarSenhaTecnico)) {
        header("Location: formTecnico.php?erroCadastro=camposVazios");
        exit();
    }

    // 2. Valida se as senhas conferem
    if ($senhaTecnico != $confirmarSenhaTecnico) {
        header("Location: formTecnico.php?erroCadastro=senhasDiferentes");
        exit();
    }

    // 3. Prepara os dados para inserção na tabela 'usuarios'
    $senhaMd5     = md5($senhaTecnico);
    $nivelUsuario = 'Tecnico'; // Define o nível como Técnico automaticamente

    // 4. Grava no banco de dados
    $sql  = "INSERT INTO usuarios (matricula_usuario, nome_usuario, email_usuario, senha_usuario, nivel_usuario) VALUES (?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "sssss", $idSiape, $nomeTecnico, $emailTecnico, $senhaMd5, $nivelUsuario);

        if (mysqli_stmt_execute($stmt)) {
            
            
            echo "
                <div class='container d-flex justify-content-center align-items-center my-5'>
                <div class='card text-center p-4 shadow-sm border-0' style='max-width: 480px; width: 100%; border-radius: 15px; background-color: #f8f9fa;'>
                    <div class='card-body'>
                        
                        <!-- Ícone de Sucesso -->
                        <div class='mb-3'>
                            <i class='bi bi-check-circle-fill text-success' style='font-size: 3.5rem;'></i>
                        </div>

                        <!-- Título e Mensagem -->
                        <h3 class='card-title fw-bold mb-2' style='color: #2b4c2a;'>Cadastro Realizado!</h3>
                        <p class='card-text text-muted mb-3'>
                            Os dados do usuário foram cadastrados com sucesso.
                        </p>

                        <!-- Tabela de Confirmação dos Dados Cadastrados -->
                        <table class='table table-bordered table-sm text-start mb-4'>
                            <tr>
                                <th class='bg-light' style='width: 35%;'>NOME:</th>
                                <td>$nomeTecnico</td>
                            </tr>
                            <tr>
                                <th class='bg-light'>MATRÍCULA:</th>
                                <td>$idSiape</td>
                            </tr>
                            <tr>
                                <th class='bg-light'>EMAIL:</th>
                                <td>$emailTecnico</td>
                            </tr>
                        </table>

                        <!-- Botão de Ação Imediata -->
                        <div class='d-grid gap-2'>
                            <a href='index.php' class='btn btn-success btn-lg fs-6 fw-bold' style='background-color: #00a84f; border: none;'>
                                <i class='bi bi-house-door me-2'></i>Ir para o Início
                            </a>
                        </div>

                        <p class='text-muted small mt-3 mb-0'>
                            Redirecionando para a página inicial em 4 segundos...
                        </p>

                    </div>
                </div>
            </div>
            ";
            mysqli_stmt_close($stmt);
            exit();
        } else {
            mysqli_stmt_close($stmt);
            header("Location: formTecnico.php?erroCadastro=erroSql");
            exit();
        }
    } else {
        header("Location: formTecnico.php?erroCadastro=erroSql");
        exit();
    }

} else {
    header("Location: formTecnico.php");
    exit();
}

include "footer.php";