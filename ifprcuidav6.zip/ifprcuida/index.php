<?php include __DIR__ . "/header.php"; ?>

<style>
    /* Estilos específicos para a página principal */
    .hero-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        text-align: center;
        padding: 2rem 1rem;
    }

    .logo-sepae {
        max-width: 260px;
        height: auto;
        margin-bottom: 2.5rem;
    }

    .hero-title {
        color: #2b4c2a; /* Verde escuro institucional */
        font-size: 1.75rem;
        font-weight: 800;
        letter-spacing: 0.5px;
        margin-bottom: 1.25rem;
        text-transform: uppercase;
    }

    .hero-subtitle {
        color: #4a5568;
        font-size: 1.05rem;
        font-weight: 600;
        max-width: 520px;
        margin-bottom: 2.5rem;
        line-height: 1.4;
    }

    .button-group {
        display: flex;
        flex-direction: column;
        gap: 1rem;
        width: 100%;
        align-items: center;
    }

    /* Estilo dos botões pill (arredondados) em verde */
    .btn-green-action {
        background-color: #00a84f; /* Verde vibrante */
        color: #ffffff !important;
        font-weight: 700;
        font-size: 1rem;
        padding: 0.9rem 2rem;
        border-radius: 50px;
        border: none;
        width: 100%;
        max-width: 440px;
        transition: background-color 0.2s, transform 0.2s, box-shadow 0.2s;
        text-decoration: none;
        display: inline-block;
        text-transform: uppercase;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    }

    .btn-green-action:hover {
        background-color: #008c42;
        transform: translateY(-2px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
    }

    /* Seção Como Funciona */
    .section-title {
        color: #2b4c2a;
        font-size: 1.75rem;
        font-weight: 800;
        text-align: center;
        margin-top: 3rem;
        margin-bottom: 1rem;
        text-transform: uppercase;
    }

    .section-description {
        color: #4a5568;
        font-weight: 600;
        text-align: center;
        max-width: 700px;
        margin: 0 auto 2rem auto;
        line-height: 1.4;
    }

    .step-card {
        background-color: #2e4d32; /* Verde escuro dos blocos */
        color: #ffffff;
        border-radius: 20px;
        padding: 1.25rem 1.75rem;
        margin-bottom: 1rem;
        text-align: center;
        font-size: 0.95rem;
        line-height: 1.5;
        max-width: 750px;
        margin-left: auto;
        margin-right: auto;
    }

    /* Seção Localização */
    .info-label {
        font-weight: 700;
        color: #2b4c2a;
    }

    .map-img {
        max-width: 280px;
        width: 100%;
        height: auto;
    }

    /* Seção Contatos */
    .contact-list {
        list-style: none;
        padding: 0;
        max-width: 800px;
        margin: 0 auto;
        font-size: 0.9rem;
        line-height: 1.6;
        color: #2b4c2a;
    }

    .contact-list li {
        margin-bottom: 0.4rem;
    }

    .contact-list a {
        color: #2b4c2a;
        text-decoration: underline;
    }
</style>

<div class="container hero-container" id="inicio">
    <img src="img/Gemini_Generated_Image_pi4g6dpi4g6dpi4g.png" alt="Logo SEPAE - Seção Pedagógica e de Assuntos Estudantis" class="logo-sepae" style="width: 100%; max-width: 400px;">

    <h1 class="hero-title">CUIDANDO DO SEU BEM ESTAR NO IFPR</h1>

    <p class="hero-subtitle">
        Agende atendimentos psicológicos e pedagógicos<br class="d-none d-md-block"> de forma sigilosa e prática.
    </p>

    <div class="button-group">
        <?php if (!isset($nivelUsuario) || $nivelUsuario === 'Estudante'): ?>
            <a href="formAgendamento.php" class="btn-green-action">
                AGENDAR ATENDIMENTO
            </a>
            <a href="formSinalRisco.php" class="btn-green-action">
                SINALIZAR AJUDA A UM COLEGA
            </a>
        <?php elseif ($nivelUsuario === 'Tecnico'): ?>
            <a href="agendamentos.php" class="btn-green-action">
                VER AGENDAMENTOS DE ALUNOS
            </a>
        <?php endif; ?>
    </div>
</div>

<!-- SEÇÃO COMO FUNCIONA -->
<div class="container my-5" id="como-funciona">
    <h2 class="section-title">COMO FUNCIONA?</h2>
    <p class="section-description">
        O IFPR Cuida foi desenvolvido para conectar você à equipe da SEPAE de forma rápida, simples e 100% segura. O processo funciona em poucas etapas:
    </p>

    <div class="step-card">
        <strong>Faça o Registro:</strong> Escolha entre pedir ajuda para você ou enviar um alerta sigiloso (e anônimo) sobre um colega em vulnerabilidade.
    </div>
    <div class="step-card">
        <strong>Triagem SEPAE:</strong> A equipe pedagógica e psicológica avalia a solicitação com total privacidade e acolhimento.
    </div>
    <div class="step-card">
        <strong>Agendamento e Atendimento:</strong> Receba a proposta de horário na plataforma, confirme a data e realize o atendimento presencial de forma segura.
    </div>
</div>

<!-- SEÇÃO LOCALIZAÇÃO -->
<div class="container my-5" id="location">
    <h2 class="section-title mb-4">LOCALIZAÇÃO</h2>
    <div class="row align-items-center justify-content-center">
        <div class="col-md-5 text-center mb-3 mb-md-0">
            <!-- Map-->
        <div class="map">
    <iframe
        src="https://maps.google.com/maps?q=IFPR%20Campus%20Tel%C3%AAmaco%20Borba,%20Tel%C3%AAmaco%20Borba,%20PR&output=embed"
        width="100%"
        height="450"
        style="border:0;"
        allowfullscreen=""
        loading="lazy">
    </iframe>
    <br />
    <small>
        <a href="https://maps.google.com/maps?q=IFPR%20Campus%20Tel%C3%AAmaco%20Borba,%20Tel%C3%AAmaco%20Borba,%20PR" target="_blank">
            Ver no Google Maps
        </a>
    </small>
</div>


        </div>
        <div class="col-md-7">
            <p><span class="info-label">Localização:</span> Sala da SEPAE — Prédio Principal do IFPR Campus Telêmaco Borba</p>
            <p><span class="info-label">Endereço:</span> Rodovia PR-160, Km 19.5, Bairro Jardim Bandeirantes, Telêmaco Borba - PR</p>
            <p><span class="info-label">Horário de Atendimento:</span> Segunda a Sexta-feira, das 08h às 22h</p>
            <p><span class="info-label">Atendimento Presencial e Online:</span> Solicite seu acolhimento diretamente pelo sistema IFPR Cuida ou visite nossa sala no campus.</p>
        </div>
    </div>
</div>

<!-- SEÇÃO CONTATOS -->
<div class="container my-5" id="contact">
    <h2 class="section-title mb-4">CONTATOS</h2>
    <ul class="contact-list text-center text-md-start">
        <li><strong>BRUNA LUQUEZ AMARAL</strong> | Assistente de Alunos - <a href="mailto:bruna.amaral@ifpr.edu.br">bruna.amaral@ifpr.edu.br</a></li>
        <li><strong>DANIELI DE CÁSSIA BARRETO GOESSLER</strong> | Psicóloga – CRP 08/10875 - <a href="mailto:danieli.barreto@ifpr.edu.br">danieli.barreto@ifpr.edu.br</a></li>
        <li><strong>DIANA ELOISE MOREIRA DA COSTA</strong> | Estagiária SEPAE - <a href="mailto:diana.costa@ifpr.edu.br">diana.costa@ifpr.edu.br</a></li>
        <li><strong>LARISSA DINIZ RIBEIRO</strong> | Pedagoga - <a href="mailto:larissa.ribeiro@ifpr.edu.br">larissa.ribeiro@ifpr.edu.br</a></li>
        <li><strong>PEDRO RENAN GOMES FELICIO</strong> | <a href="mailto:pedro.felicio@ifpr.edu.br">pedro.felicio@ifpr.edu.br</a></li>
        <li><strong>PRISCILA GODOY</strong> | Pedagoga - <a href="mailto:priscila.godoy@ifpr.edu.br">priscila.godoy@ifpr.edu.br</a></li>
        <li><strong>SANDRA AUGUSTO SILVA</strong> | Técnica em Assuntos Educacionais - <a href="mailto:sandra.silva@ifpr.edu.br">sandra.silva@ifpr.edu.br</a></li>
        <li><strong>MOISÉS ESPÍRITO SANTO</strong> | Assistente de Alunos - <a href="mailto:moises.santo@ifpr.edu.br">moises.santo@ifpr.edu.br</a></li>
    </ul>
</div>

<?php include("footer.php"); ?>