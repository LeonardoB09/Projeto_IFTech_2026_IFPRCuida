<?php

    if(!isset($_SESSION['logado']) && $_SESSION['logado'] === false){
        header('location:formLogin.php?erroLogin=naoLogado');
    }

?>