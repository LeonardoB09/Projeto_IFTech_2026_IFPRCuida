
<?php

include 'header.php';
include 'conexaoBD.php';

// Busca os agendamentos junto com o nome do usuário
$sql = "SELECT 
            a.id_agendamento,
            a.id_usuario,
            u.nome_usuario,
            a.data_agendamento,
            a.horario_agendamento,
            a.motivo_agendamento,
            a.status_agendamento
        FROM agendamento a
        INNER JOIN usuarios u 
            ON a.id_usuario = u.id_usuario
        ORDER BY a.data_agendamento DESC, a.horario_agendamento DESC";

$resultado = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Agendamentos</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

</head>

<body class="bg-light">

<div class="container py-5">

    <!-- Cabeçalho -->
    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>
            <h2 class="fw-bold mb-1">
                <i class="bi bi-calendar-check"></i>
                Agendamentos
            </h2>

            <p class="text-muted mb-0">
                Lista de agendamentos realizados
            </p>
        </div>

        <a href="index.php" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i>
            Voltar
        </a>

    </div>


    <!-- Tabela -->
    <div class="card shadow-sm border-0">

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-hover align-middle mb-0">

                    <thead class="table-dark">

                        <tr>

                            <th>#</th>

                            <th>Usuário</th>

                            <th>Data</th>

                            <th>Horário</th>

                            <th>Motivo</th>

                            <th>Status</th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php if (mysqli_num_rows($resultado) > 0): ?>

                        <?php while ($agendamento = mysqli_fetch_assoc($resultado)): ?>

                            <?php

                            // Formata a data
                            $data = date(
                                'd/m/Y',
                                strtotime($agendamento['data_agendamento'])
                            );

                            // Formata o horário
                            $horario = date(
                                'H:i',
                                strtotime($agendamento['horario_agendamento'])
                            );


                            // Define a cor do status
                            switch (strtolower($agendamento['status_agendamento'])) {

                                case 'pendente':
                                    $classeStatus = 'bg-warning text-dark';
                                    break;

                                case 'confirmado':
                                    $classeStatus = 'bg-success';
                                    break;

                                case 'cancelado':
                                    $classeStatus = 'bg-danger';
                                    break;

                                case 'concluido':
                                case 'concluído':
                                    $classeStatus = 'bg-primary';
                                    break;

                                default:
                                    $classeStatus = 'bg-secondary';
                            }

                            ?>

                            <tr>

                                <!-- ID -->
                                <td>
                                    <strong>
                                        <?= $agendamento['id_agendamento'] ?>
                                    </strong>
                                </td>


                                <!-- Nome do usuário -->
                                <td>

                                    <i class="bi bi-person-circle text-secondary"></i>

                                    <?= htmlspecialchars($agendamento['nome_usuario']) ?>

                                </td>


                                <!-- Data -->
                                <td>

                                    <i class="bi bi-calendar3 text-primary"></i>

                                    <?= $data ?>

                                </td>


                                <!-- Horário -->
                                <td>

                                    <i class="bi bi-clock text-primary"></i>

                                    <?= $horario ?>

                                </td>


                                <!-- Motivo -->
                                <td>

                                    <?= htmlspecialchars($agendamento['motivo_agendamento']) ?>

                                </td>


                                <!-- Status -->
                                <td>

                                    <span class="badge <?= $classeStatus ?>">

                                        <?= ucfirst(
                                            htmlspecialchars(
                                                $agendamento['status_agendamento']
                                            )
                                        ) ?>

                                    </span>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <tr>

                            <td colspan="6" class="text-center py-4 text-muted">

                                <i class="bi bi-calendar-x fs-3"></i>

                                <p class="mt-2 mb-0">
                                    Nenhum agendamento encontrado.
                                </p>

                            </td>

                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

<?php include 'footer.php'; ?>