<?php include "header.php"; ?>

<?php
    if (isset($_GET['erroLogin'])) {
        $erroLogin = $_GET['erroLogin'];

        if ($erroLogin === 'dadosInvalidos') {
            echo "<div class='alert alert-warning text-center mt-3'>E-mail ou senha inválidos!</div>";
        }
    }
?>

<div class="d-flex justify-content-center mt-4">
    <h2>Acessar o Sistema:</h2>
</div>

<div class="d-flex justify-content-center">
    <form action="actionLogin.php" method="POST" class="was-validated">
        
        <div class="form-floating mt-3 mb-3">
            <input type="email" name="emailUsuario" id="emailUsuario" placeholder="Email" class="form-control" required>
            <label for="emailUsuario">E-mail</label>
        </div>

        <div class="form-floating mt-3 mb-3">
            <input type="password" name="senhaUsuario" id="senhaUsuario" placeholder="Senha" class="form-control" required>
            <label for="senhaUsuario">Senha</label>
        </div>

        <button type="submit" class="btn btn-outline-dark">Entrar</button>

    </form>
</div>

<div class="d-flex justify-content-center mt-3">
    <p>Ainda não é cadastrado? <a href="formTecnico.php" title="Cadastrar-se">Clique aqui!</a>&nbsp;<i class="bi bi-emoji-smile"></i></p>
</div>

<?php include "footer.php"; ?>