<?php
// Inicia a sessão se ela ainda não estiver ativa
if (session_status() === PHP_SESSION_NONE) {
    error_reporting(0); //Desabilita alertas de erros de execução
    session_start();
}

// Verifica se há sessão ativa, independentemente de onde ela foi iniciada
$nivelUsuario = null;
if (isset($_SESSION['logado']) && $_SESSION['logado'] === true) {
    $idUsuario    = $_SESSION['idUsuario']; //Armazenar as variáveis de sessão em variáveis PHP
    $nomeUsuario  = $_SESSION['nomeUsuario'];
    $emailUsuario = $_SESSION['emailUsuario'];
    $nivelUsuario = $_SESSION['nivelUsuario'];

    $nomeCompleto = explode(' ', $nomeUsuario); //Usa a função explode para fragmentar o nome do usuário
    $primeiroNome = $nomeCompleto[0]; //Armazena na variável o primeiro [0] fragmento do nome do usuário
}
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title>IFPR CUIDA</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        
        <style>
            body {
                display: flex;
                flex-direction: column;
                min-height: 100vh;
            }

            .custom-header {
                background-color: #689f63; /* Verde extraído do protótipo */
                padding: 0.8rem 0;
                width: 100%;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }

            .header-container {
                display: flex;
                align-items: center;
                max-width: 1320px;
                margin: 0 auto;
                padding: 0 1.5rem;
            }

            .logo-link {
                display: flex;
                align-items: center;
                text-decoration: none;
                color: inherit;
            }

            .logo-group {
                display: flex;
                align-items: center;
                gap: 1rem;
            }

            .logo-img {
                height: 70px; /* Ajustado para caber harmoniosamente no header */
                width: auto;
                object-fit: contain;
            }

            .logo-title {
                margin: 0;
                font-size: 1.5rem;
                font-weight: 700;
                color: #ffffff; /* Texto branco */
            }

            .logo-subtitle {
                margin: 0;
                font-size: 0.75rem;
                color: #f0f0f0; /* Texto claro */
            }

            .custom-nav {
                flex-grow: 1;
                display: flex;
                justify-content: flex-end;
            }

            .nav-list {
                list-style: none;
                padding: 0;
                margin: 0;
                display: flex;
                align-items: center;
                gap: 2rem;
            }

            .nav-list li a {
                text-decoration: none;
                color: #ffffff; /* Links em branco como na imagem */
                text-transform: uppercase;
                font-weight: 700;
                font-size: 0.95rem;
                transition: opacity 0.2s;
            }

            .nav-list li a:hover {
                color: #e2fcd6; /* Efeito leve ao passar o mouse */
            }

            /* Estilo específico para o menu do usuário logado */
            .user-menu {
                text-transform: none !important;
                display: flex;
                align-items: center;
                gap: 0.5rem;
                background-color: rgba(255, 255, 255, 0.2);
                color: #ffffff !important;
                padding: 0.4rem 0.8rem;
                border-radius: 20px;
                transition: background 0.2s;
            }

            .user-menu:hover {
                background-color: rgba(255, 255, 255, 0.35);
            }

            main {
                flex: 1;
            }
        </style>
    </head>
    <body>
        <header class="custom-header">
            <div class="header-container">
                <a href="index.php" class="logo-link">
                    <div class="logo-group">
                        <img src="img/Gemini_Generated_Image_5zjl5x5zjl5x5zjl (2).png" alt="Logo IFPR CUIDA" class="logo-img">
                        <div class="logo-text">
                            <h2 class="logo-title">IFPR CUIDA</h2>
                            <p class="logo-subtitle">Sistema de Apoio à Saúde Mental Estudantil</p>
                        </div>
                    </div>
                </a>
                <nav class="custom-nav">
                    <ul class="nav-list">
                        <li><a href="index.php">INÍCIO</a></li>
                        <li><a href="index.php#location">LOCALIZAÇÃO</a></li>
                        <li><a href="index.php#contact">CONTATOS</a></li>

                        <?php if (isset($_SESSION['logado']) && $_SESSION['logado'] === true): ?>
                            <?php if ($nivelUsuario === 'Estudante'): ?>
                                <li><a href="meusAgendamentos.php">AGENDAMENTOS</a></li>
                                <li><a href="formSinalRisco.php">SINALIZAR AJUDA</a></li>
                            <?php elseif ($nivelUsuario === 'Tecnico'): ?>
                                <li><a href="agendamentos.php">AGENDAMENTOS DE ALUNOS</a></li>
                            <?php endif; ?>
                            <!-- EXIBIDO APENAS QUANDO LOGADO -->
                            <li class="dropdown">
                                <a href="#" class="user-menu dropdown-toggle text-dark" id="dropdownUser" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="bi bi-person-circle fs-5"></i>
                                    <span><?php echo htmlspecialchars($_SESSION['nomeUsuario']); ?></span>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="dropdownUser">
                                    <li>
                                        <span class="dropdown-item-text text-muted small">
                                            Nível: <strong><?php echo htmlspecialchars($_SESSION['nivelUsuario']); ?></strong>
                                        </span>
                                    </li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <a class="dropdown-item text-danger" href="logout.php">
                                            <i class="bi bi-box-arrow-right me-2"></i>Sair
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        <?php else: ?>
                            <!-- EXIBIDO APENAS QUANDO DESLOGADO -->
                            <li>
                                <a href="botoes.php" class="user-menu" onclick="window.location.href='botoes.php'; return false;">
                                    <i class="bi bi-person-circle fs-5"></i>
                                    <span>LOGIN</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </header>

        <!-- Abertura do conteúdo principal -->
        <main class="py-5">